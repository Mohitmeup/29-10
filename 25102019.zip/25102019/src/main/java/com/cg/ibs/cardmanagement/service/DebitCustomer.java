package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCustomer {

	public List<DebitCardBean> viewAllDebitCards() throws IBSException;
	
	


	String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice) throws IBSException;

	void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException;


	
	String applyNewDebitCard(BigInteger accountNumber, String newCardType) throws IBSException;

	String requestDebitCardLost(BigInteger debitCardNumber) throws IBSException;

	String raiseDebitMismatchTicket(String transactionId) throws IBSException;
	public List<DebitCardTransaction> getDebitTransactions(int dys, BigInteger debitCardNumber) throws IBSException;
	

	


}
