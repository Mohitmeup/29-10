package com.cg.ibs.cardmanagement.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardBean;

import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCardDaoImpl implements CreditCardDao {
	public List<CreditCardBean> viewAllCreditCards() throws IBSException {
		String sql = SqlQueries.SELECT_DATA_FROM_CREDIT_CARD;
		List<CreditCardBean> creditCards = new ArrayList<CreditCardBean>();
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					CreditCardBean crd = new CreditCardBean();

					crd.setCardNumber(resultSet.getBigDecimal("credit_card_num").toBigInteger());
					crd.setCardStatus(resultSet.getString("credit_card_status"));
					crd.setNameOnCard(resultSet.getString("name_on_cred_card"));
					crd.setCvvNum(resultSet.getString("credit_cvv_num"));
					crd.setDateOfExpiry(resultSet.getDate("credit_expiry_date").toLocalDate());
					crd.setCardType(resultSet.getString("credit_card_type"));

					creditCards.add(crd);

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return creditCards;

	}

	

//	
//			LocalDateTime fromDate1 = LocalDateTime.now().minusDays(days);
//			LocalDateTime currentDate1 = LocalDateTime.now();
//			Timestamp timestamp1 = Timestamp.valueOf(fromDate1);
//			Timestamp timestamp2 = Timestamp.valueOf(currentDate1);
//			preparedStatement.setTimestamp(1, timestamp1);
//			preparedStatement.setTimestamp(2, timestamp2);
//			preparedStatement.setBigDecimal(3, new BigDecimal(debitCardNumber));
//

	
	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		boolean result = false;

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.VERIFY_CREDIT_CARD_NUM);) {
			preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {

					result = true;
				}

			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

		return result;
	}
	
	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {

		String sql = SqlQueries.SET_CREDIT_CARD_PIN;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

			preparedStatement.setString(1, newPin);
			preparedStatement.setBigDecimal(2, new BigDecimal(creditCardNumber));
			preparedStatement.executeUpdate();

		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String getCreditCardPin(BigInteger creditCardNumber) throws IBSException {
		String sql = SqlQueries.GET_CREDIT_CARD_PIN;
		String creditCardPin = null;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				creditCardPin = resultSet.getString("credit_cur_pin");

			}

		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

		return creditCardPin;

	}

	
	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException {
		BigInteger creditCardUci = null;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_CREDIT_UCI)) {
			preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					creditCardUci = resultSet.getBigDecimal("UCI").toBigInteger();

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return creditCardUci;
	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) throws IBSException {

		String sql = SqlQueries.GET_CREDIT_CARD_TYPE;
		String type = new String();
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					type = resultSet.getString("credit_card_type");

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return type;
	}
	
	
		
	

		

	
		@Override
		public String getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
			String creditStatus = new String();
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_CREDIT_CARD_STATUS);) {
				preparedStatement.setBigDecimal(1, new BigDecimal(creditCardNumber));

				try (ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						creditStatus = resultSet.getString("credit_card_status");

					}

				} catch (Exception e) {
					throw new IBSException(ErrorMessages.INTERNAL_ERROR);

				}
			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			return creditStatus;
		}
		


		
		@Override
		public boolean actionANCC(String queryId, CreditCardBean bean1) throws IBSException {
			BigInteger uci = null;
			boolean result = false;
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement(SqlQueries.GET_DETAILS_CREDIT_CARD_NEW);) {
				preparedStatement.setString(1, queryId);
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					while (resultSet.next()) {
						uci = resultSet.getBigDecimal("UCI").toBigInteger();
					}
				}
			} catch (SQLException | IOException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement2 = connection
							.prepareStatement(SqlQueries.ACTION_CREDIT_CARD_NEW);) {
				preparedStatement2.setBigDecimal(1, new BigDecimal(bean1.getCardNumber()));
				preparedStatement2.setString(2, bean1.getCardStatus());
				preparedStatement2.setString(3, bean1.getNameOnCard());
				preparedStatement2.setString(4, bean1.getCvvNum());
				preparedStatement2.setString(5, bean1.getCurrentPin());
				preparedStatement2.setDate(6, java.sql.Date.valueOf(bean1.getDateOfExpiry()));
				preparedStatement2.setBigDecimal(7, new BigDecimal(uci));
				preparedStatement2.setString(8, bean1.getCardType());
				preparedStatement2.setInt(9, bean1.getCreditScore());
				preparedStatement2.setBigDecimal(10, bean1.getCreditLimit());
				preparedStatement2.setDouble(11, bean1.getIncome());
				if (preparedStatement2.executeUpdate() > 0) {
					result = true;
				}

			} catch (SQLException | IOException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			return result;
		}
		
		

		@Override
		public void actionBlockCC(String queryId, String status) throws IBSException {
			BigInteger creditCardNum = null;
			// String creditCardStatus = "";
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_DETAILS_CARD_BLOCK)) {
				preparedStatement.setString(1, queryId);
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					while (resultSet.next()) {
						creditCardNum = resultSet.getBigDecimal("card_num").toBigInteger();
						// creditCardStatus = resultSet.getString("define_query");
					}
				}
			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement2 = connection
							.prepareStatement(SqlQueries.ACTION_CREDIT_CARD_BLOCK);) {
				preparedStatement2.setString(1, status);
				preparedStatement2.setBigDecimal(2, new BigDecimal(creditCardNum));
				preparedStatement2.executeUpdate();
			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}

		}

		

		@Override
		public void actionUpgradeCC(String queryId) throws IBSException {
			BigInteger creditCardNum = null;
			String creditCardType = "";
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement = connection
							.prepareStatement(SqlQueries.GET_DETAILS_CARD_UPGRADE);) {
				preparedStatement.setString(1, queryId);
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					while (resultSet.next()) {
						creditCardNum = resultSet.getBigDecimal("card_num").toBigInteger();
						creditCardType = resultSet.getString("define_query");
					}
				}
			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}
			try (Connection connection = ConnectionProvider.getInstance().getConnection();
					PreparedStatement preparedStatement2 = connection
							.prepareStatement(SqlQueries.ACTION_CREDIT_CARD_UPGRADE)) {
				preparedStatement2.setString(1, creditCardType);
				preparedStatement2.setBigDecimal(2, new BigDecimal(creditCardNum));
				preparedStatement2.executeUpdate();
			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}

		}

		
		
	}
		
