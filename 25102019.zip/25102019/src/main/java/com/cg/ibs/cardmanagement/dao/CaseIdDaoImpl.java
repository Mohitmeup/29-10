package com.cg.ibs.cardmanagement.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

import java.util.List;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CaseIdDaoImpl implements CaseIdDao {
	@Override
	public boolean verifyQueryId(String queryId) throws IBSException {
		boolean result = false;

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.VERIFY_QUERY_ID);) {
			preparedStatement.setString(1, queryId);

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {

					result = true;
				}

			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

		return result;
	}

	@Override
	public List<CaseIdBean> viewAllQueries() throws IBSException {

		List<CaseIdBean> query = null;

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.SELECT_DATA_FROM_QUERY_TABLE);) {

			try (ResultSet resultSet1 = preparedStatement.executeQuery()) {
				query = new ArrayList<>();

				while (resultSet1.next()) {

					CaseIdBean caseIdObj = new CaseIdBean();
					Timestamp timestamp = resultSet1.getTimestamp("case_timestamp");
					LocalDateTime localDateTime = timestamp.toLocalDateTime();

					caseIdObj.setCaseIdTotal(resultSet1.getString("query_id"));
					caseIdObj.setCaseTimeStamp(localDateTime);
					caseIdObj.setStatusOfServiceRequest(resultSet1.getString("status_of_query"));
					caseIdObj.setAccountNumber(BigInteger.valueOf(resultSet1.getLong("account_num")));
					caseIdObj.setUCI(BigInteger.valueOf(resultSet1.getLong("UCI")));
					caseIdObj.setDefineServiceRequest(resultSet1.getString("define_query"));

					caseIdObj.setCardNumber(BigInteger.valueOf(resultSet1.getLong("card_num")));
					caseIdObj.setCustomerReferenceId(resultSet1.getString("customer_reference_ID"));

					query.add(caseIdObj);

				}

			} catch (Exception e) {

				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return query;
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) throws IBSException {

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.SET_QUERY_STATUS);) {
			preparedStatement.setString(1, newStatus);
			preparedStatement.setString(2, queryId);

			preparedStatement.executeUpdate();
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String getNewType(String queryId) throws IBSException {
		String type = "";
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_CARD_TYPE);) {
			preparedStatement.setString(1, queryId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					type = resultSet.getString("define_query");
				}
			}
		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return type;
	}

	@Override
	public void requestCreditCardUpgrade(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException {

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_CREDIT_CARD_UPGRADE)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());

			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(6, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(7, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}
	}

	@Override
	public String getCustomerReferenceId(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException {

		String custReferenceStatus = null;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.GET_CUSTOMER_REFERENCE_ID)) {
			preparedStatement.setString(1, customerReferenceId);

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					custReferenceStatus = resultSet.getString("status_of_query");

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return custReferenceStatus;

	}

	@Override
	public void raiseCreditMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException {
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_CREDIT_MISMATCH_TICKET)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());

			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(6, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(7, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public void requestCreditCardLost(CaseIdBean caseIdObj, BigInteger creditCardNumber) throws IBSException {

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_CREDIT_CARD_LOST);) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());

			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(6, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(7, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}
	}

	@Override
	public void requestDebitCardUpgrade(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException {
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_DEBIT_CARD_UPGRADE)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));

			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getAccountNumber()));
			preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));

			preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(7, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(8, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public void requestDebitCardLost(CaseIdBean caseIdObj, BigInteger debitCardNumber) throws IBSException {
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_DEBIT_CARD_LOST);) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));

			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getAccountNumber()));

			preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(7, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(8, caseIdObj.getCustomerReferenceId());

			preparedStatement.executeUpdate();
			preparedStatement.close();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public void raiseDebitMismatchTicket(CaseIdBean caseIdObj, String transactionId) throws IBSException {
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.REQUEST_DEBIT_MISMATCH_TICKET)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());

			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getAccountNumber()));

			preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());

			preparedStatement.setBigDecimal(7, new BigDecimal(caseIdObj.getCardNumber()));
			preparedStatement.setString(8, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}
	}

	@Override
	public void newDebitCard(CaseIdBean caseIdObj, BigInteger accountNumber) throws IBSException {
		String sql = SqlQueries.APPLY_NEW_DEBIT_CARD;

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(caseIdObj.getCaseTimeStamp().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getAccountNumber()));
			preparedStatement.setBigDecimal(5, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(6, caseIdObj.getDefineServiceRequest());

			preparedStatement.setString(7, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public BigInteger getNewUCI(String queryId) throws IBSException {
		BigInteger uci = null;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.GET_CREDIT_CARD_UCI);) {
			preparedStatement.setString(1, queryId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					uci = resultSet.getBigDecimal("uci").toBigInteger();
				}
			}
		} catch (SQLException | IOException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return uci;
	}

	@Override
	public void newCreditCard(CaseIdBean caseIdObj) throws IBSException {
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SqlQueries.APPLY_NEW_CREDIT_CARD)) {

			preparedStatement.setString(1, caseIdObj.getCaseIdTotal());
			preparedStatement.setDate(2, java.sql.Date.valueOf(LocalDateTime.now().toLocalDate()));
			preparedStatement.setString(3, caseIdObj.getStatusOfServiceRequest());
			preparedStatement.setBigDecimal(4, new BigDecimal(caseIdObj.getUCI()));
			preparedStatement.setString(5, caseIdObj.getDefineServiceRequest());
			preparedStatement.setString(6, caseIdObj.getCustomerReferenceId());
			preparedStatement.executeUpdate();

		} catch (SQLException | IOException e) {
			// log.error(Arrays.toString(e.getStackTrace()));
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

}
