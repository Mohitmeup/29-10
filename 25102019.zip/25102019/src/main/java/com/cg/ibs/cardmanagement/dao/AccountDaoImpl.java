package com.cg.ibs.cardmanagement.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class AccountDaoImpl implements AccountDao {

	@Override
	public BigInteger getUci(BigInteger accountNumber) throws IBSException {

		String sql = SqlQueries.GET_NDC_UCI;
		BigInteger ndcUci = null;
		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
			preparedStatement.setBigDecimal(1, new BigDecimal(accountNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {

					ndcUci = resultSet.getBigDecimal("UCI").toBigInteger();

				}

			} catch (Exception e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);

			}
		} catch (Exception e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
		return ndcUci;
	}

	

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		boolean result = false;

		try (Connection connection = ConnectionProvider.getInstance().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SqlQueries.VERIFY_ACCOUNT_NUM_FROM_ACCOUNT);) {
			preparedStatement.setBigDecimal(1, new BigDecimal(accountNumber));

			try (ResultSet resultSet = preparedStatement.executeQuery();) {

				if (resultSet.next()) {

					result = true;
				}

			}
		} catch (Exception e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

		return result;
	}
	

}
